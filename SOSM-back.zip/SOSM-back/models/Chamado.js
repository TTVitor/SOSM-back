const mongoose = require("mongoose");

const chamadoSchema = new mongoose.Schema({
  titulo: { type: String, required: true },
  descricao: { type: String, required: true },
  status: {
    type: String,
    enum: ["Aberto", "Em andamento", "Concluído", "Fechado"],
    default: "Aberto"
  },
  prioridade: {
    type: String,
    enum: ["Baixa", "Média", "Alta"],
    default: "Média"
  },
  criadoPor: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  atribuidoPara: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  historico: [{
    mensagem: String,
    criadoEm: { type: Date, default: Date.now },
    autor: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
  }],
  criadoEm: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Chamado", chamadoSchema);
