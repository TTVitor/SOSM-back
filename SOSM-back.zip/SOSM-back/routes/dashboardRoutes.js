const express = require("express");
const router = express.Router();
const dashboardController = require("../controllers/dashboardController");
const { proteger, permissao } = require("../middlewares/authMiddlewares");

// Apenas admin ou atendente acessam o dashboard
router.get("/status", proteger, permissao("admin", "atendente"), dashboardController.chamadosPorStatus);
router.get("/prioridade", proteger, permissao("admin", "atendente"), dashboardController.chamadosPorPrioridade);
router.get("/mensal", proteger, permissao("admin", "atendente"), dashboardController.chamadosPorMes);
router.get("/usuarios", proteger, permissao("admin"), dashboardController.usuariosPorPapel);

module.exports = router;
