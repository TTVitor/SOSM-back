const express = require("express");
const router = express.Router();
const chamadoController = require("../controllers/chamadoController");
const { proteger, permissao } = require("../middlewares/authMiddlewares");

// ----- CLIENTE -----
router.post("/", proteger, permissao("cliente"), chamadoController.criarChamado);
router.get("/meus", proteger, permissao("cliente"), chamadoController.listarMeusChamados);

// ----- ADMIN/ATENDENTE -----
router.get("/", proteger, permissao("admin", "atendente"), chamadoController.listarTodosChamados);
router.get("/:id", proteger, chamadoController.detalharChamado);
router.put("/atribuir/:id", proteger, permissao("admin"), chamadoController.atribuirChamado);
router.put("/status/:id", proteger, permissao("admin", "atendente"), chamadoController.atualizarStatus);
router.put("/mensagem/:id", proteger, chamadoController.adicionarMensagem);
router.put("/prioridade/:id", proteger, permissao("admin", "atendente"), chamadoController.atualizarPrioridade);

// ----- ADMIN -----
router.delete("/:id", proteger, permissao("admin"), chamadoController.deletarChamado);
router.put("/:id", proteger, permissao("admin"), chamadoController.editarChamado);

// ----- ESTATÍSTICAS / DASHBOARD -----
router.get("/estatisticas/resumo", proteger, permissao("admin", "atendente"), chamadoController.obterEstatisticasGerais);
router.get("/estatisticas/status", proteger, permissao("admin", "atendente"), chamadoController.chamadosPorStatus);
router.get("/estatisticas/atendentes", proteger, permissao("admin"), chamadoController.chamadosPorAtendente);

module.exports = router;
