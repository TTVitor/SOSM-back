const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const conectarDB = require("./config/db"); // NOVO

dotenv.config();

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Rotas básicas
app.get("/", (req, res) => {
  res.send("API Help Desk rodando");
});

// Rotas da aplicação
const authRoutes = require("./routes/authRoutes");
app.use("/api/auth", authRoutes);

const chamadoRoutes = require("./routes/chamadoRoutes");
app.use("/api/chamados", chamadoRoutes);

const dashboardRoutes = require("./routes/dashboardRoutes");
app.use("/api/dashboard", dashboardRoutes);

// Conectar ao banco e iniciar o servidor
const PORT = process.env.PORT || 5000;
conectarDB().then(() => {
  app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando na porta ${PORT}`);
  });
});

// Rota 404
app.use((req, res) => {
  res.status(404).send("Rota não encontrada");
});
