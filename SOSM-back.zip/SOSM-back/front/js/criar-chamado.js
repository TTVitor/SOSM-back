document.addEventListener("DOMContentLoaded", () => {
    const token = localStorage.getItem("token");
  
    if (!token) {
      window.location.href = "login.html";
      return;
    }
  
    const form = document.getElementById("chamadoForm");
    const msg = document.getElementById("mensagem");
  
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
  
      const titulo = document.getElementById("titulo").value;
      const descricao = document.getElementById("descricao").value;
      const prioridade = document.getElementById("prioridade").value;
  
      try {
        const res = await fetch("http://localhost:3000/api/chamados", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
          },
          body: JSON.stringify({ titulo, descricao, prioridade })
        });
  
        const data = await res.json();
  
        if (!res.ok) {
          msg.textContent = data.erro || "Erro ao criar chamado.";
          msg.style.color = "red";
          return;
        }
  
        msg.textContent = "✅ Chamado criado com sucesso!";
        msg.style.color = "green";
        form.reset();
      } catch (err) {
        console.error(err);
        msg.textContent = "Erro de conexão com o servidor.";
        msg.style.color = "red";
      }
    });
  });
  