document.addEventListener("DOMContentLoaded", () => {
    const token = localStorage.getItem("token");
    const container = document.getElementById("chamadosContainer");
    const filtro = document.getElementById("filtro");
  
    if (!token) {
      window.location.href = "login.html";
      return;
    }
  
    async function carregarChamados(status = "") {
      container.innerHTML = "<p>Carregando chamados...</p>";
  
      try {
        const res = await fetch(`http://localhost:3000/api/chamados?status=${status}`, {
          headers: {
            "Authorization": "Bearer " + token
          }
        });
  
        const chamados = await res.json();
        container.innerHTML = "";
  
        if (chamados.length === 0) {
          container.innerHTML = "<p>Nenhum chamado encontrado.</p>";
          return;
        }
  
        chamados.forEach(c => {
          const div = document.createElement("div");
          div.classList.add("chamado-card");
          div.innerHTML = `
            <h3>${c.titulo}</h3>
            <p><strong>Status atual:</strong> ${c.status}</p>
            <p><strong>Prioridade:</strong> ${c.prioridade}</p>
            <p><strong>Descrição:</strong> ${c.descricao}</p>
            <label for="novoStatus-${c._id}">Alterar status:</label>
            <select id="novoStatus-${c._id}">
              <option value="Aberto" ${c.status === "Aberto" ? "selected" : ""}>Aberto</option>
              <option value="Em andamento" ${c.status === "Em andamento" ? "selected" : ""}>Em andamento</option>
              <option value="Concluído" ${c.status === "Concluído" ? "selected" : ""}>Concluído</option>
            </select>
            <button onclick="atualizarStatus('${c._id}')">Salvar</button>
            <hr />
          `;
          container.appendChild(div);
        });
      } catch (err) {
        console.error(err);
        container.innerHTML = "<p style='color:red;'>Erro ao carregar chamados.</p>";
      }
    }
  
    filtro.addEventListener("change", () => {
      carregarChamados(filtro.value);
    });
  
    carregarChamados(); // Inicial
  
    window.atualizarStatus = async function (id) {
      const novoStatus = document.getElementById(`novoStatus-${id}`).value;
  
      try {
        const res = await fetch(`http://localhost:3000/api/chamados/${id}/status`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
          },
          body: JSON.stringify({ status: novoStatus })
        });
  
        if (res.ok) {
          alert("✅ Status atualizado!");
          carregarChamados(filtro.value); // Recarrega
        } else {
          alert("Erro ao atualizar status");
        }
      } catch (err) {
        console.error(err);
        alert("Erro de conexão");
      }
    };
  });
  