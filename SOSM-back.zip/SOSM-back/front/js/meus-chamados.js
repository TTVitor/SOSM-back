document.addEventListener("DOMContentLoaded", () => {
    const token = localStorage.getItem("token");
    const container = document.getElementById("chamadosContainer");
  
    if (!token) {
      window.location.href = "login.html";
      return;
    }
  
    fetch("http://localhost:3000/api/chamados/meus", {
      headers: {
        "Authorization": "Bearer " + token
      }
    })
      .then(res => res.json())
      .then(data => {
        container.innerHTML = ""; // limpa o "carregando..."
        
        if (data.length === 0) {
          container.innerHTML = "<p>Nenhum chamado encontrado.</p>";
          return;
        }
  
        data.forEach(chamado => {
          const div = document.createElement("div");
          div.classList.add("chamado-card");
          div.innerHTML = `
            <h3>${chamado.titulo}</h3>
            <p><strong>Status:</strong> ${chamado.status}</p>
            <p><strong>Prioridade:</strong> ${chamado.prioridade}</p>
            <p><strong>Criado em:</strong> ${new Date(chamado.criadoEm).toLocaleDateString()}</p>
            <hr />
          `;
          container.appendChild(div);
        });
      })
      .catch(err => {
        console.error(err);
        container.innerHTML = "<p style='color:red;'>Erro ao carregar chamados.</p>";
      });
  });
  