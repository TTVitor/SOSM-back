document.addEventListener("DOMContentLoaded", () => {
    const token = localStorage.getItem("token"); // ou troque por token fixo durante o teste
  
    fetch("http://localhost:3000/api/dashboard", {
      headers: {
        Authorization: "Bearer " + token
      }
    })
      .then(res => res.json())
      .then(data => {
        document.getElementById("totalChamados").textContent = data.totalChamados;
  
        // Gráfico por status
        const statusCtx = document.getElementById("statusChart").getContext("2d");
        new Chart(statusCtx, {
          type: "bar",
          data: {
            labels: data.chamadosPorStatus.map(s => s._id),
            datasets: [{
              label: "Chamados por Status",
              data: data.chamadosPorStatus.map(s => s.total),
              backgroundColor: "rgba(54, 162, 235, 0.6)"
            }]
          }
        });
  
        // Gráfico por prioridade
        const prioridadeCtx = document.getElementById("prioridadeChart").getContext("2d");
        new Chart(prioridadeCtx, {
          type: "pie",
          data: {
            labels: data.chamadosPorPrioridade.map(p => p._id),
            datasets: [{
              label: "Prioridade",
              data: data.chamadosPorPrioridade.map(p => p.total),
              backgroundColor: ["#f87171", "#facc15", "#4ade80"]
            }]
          }
        });
  
        // Lista de usuários
        const lista = document.getElementById("usuariosLista");
        data.chamadosPorUsuario.forEach(user => {
          const li = document.createElement("li");
          li.textContent = `${user.nome}: ${user.total} chamados`;
          lista.appendChild(li);
        });
      })
      .catch(err => {
        alert("Erro ao carregar dashboard");
        console.error(err);
      });
  });
  