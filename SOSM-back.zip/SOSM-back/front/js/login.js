document.getElementById("loginForm").addEventListener("submit", async (e) => {
    e.preventDefault();
  
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;
  
    try {
      const res = await fetch("http://localhost:3000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, senha })
      });
  
      const data = await res.json();
  
      if (!res.ok) {
        document.getElementById("erro").textContent = data.erro || "Login falhou.";
        return;
      }
  
      // Salvar token no localStorage
      localStorage.setItem("token", data.token);
  
      // Redirecionar para dashboard
      window.location.href = "index.html";
    } catch (err) {
      console.error(err);
      document.getElementById("erro").textContent = "Erro ao conectar com o servidor.";
    }
  });
  