const Chamado = require("../models/Chamado");
const User = require("../models/User");

exports.chamadosPorStatus = async (req, res) => {
  try {
    const resultado = await Chamado.aggregate([
      { $group: { _id: "$status", total: { $sum: 1 } } }
    ]);
    res.json(resultado);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao buscar chamados por status" });
  }
};

exports.chamadosPorPrioridade = async (req, res) => {
  try {
    const resultado = await Chamado.aggregate([
      { $group: { _id: "$prioridade", total: { $sum: 1 } } }
    ]);
    res.json(resultado);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao buscar chamados por prioridade" });
  }
};

exports.chamadosPorMes = async (req, res) => {
  try {
    const umMesAtras = new Date();
    umMesAtras.setMonth(umMesAtras.getMonth() - 1);

    const resultado = await Chamado.aggregate([
      { $match: { criadoEm: { $gte: umMesAtras } } },
      {
        $group: {
          _id: {
            dia: { $dayOfMonth: "$criadoEm" },
            mes: { $month: "$criadoEm" },
            ano: { $year: "$criadoEm" },
          },
          total: { $sum: 1 }
        }
      },
      { $sort: { "_id.ano": 1, "_id.mes": 1, "_id.dia": 1 } }
    ]);

    res.json(resultado);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao buscar chamados do mês" });
  }
};

exports.usuariosPorPapel = async (req, res) => {
  try {
    const resultado = await User.aggregate([
      { $group: { _id: "$papel", total: { $sum: 1 } } }
    ]);
    res.json(resultado);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao buscar usuários por papel" });
  }
};
