const User = require("../models/User");
const jwt = require("jsonwebtoken");

const gerarToken = (user) => {
  return jwt.sign(
    { id: user._id, papel: user.papel },
    process.env.JWT_SECRET,
    { expiresIn: "1d" }
  );
};

exports.registrar = async (req, res) => {
  try {
    const { nome, email, senha, papel } = req.body;
    const jaExiste = await User.findOne({ email });
    if (jaExiste) return res.status(400).json({ erro: "Email já cadastrado" });

    const novoUsuario = new User({ nome, email, senha, papel });
    await novoUsuario.save();

    const token = gerarToken(novoUsuario);
    res.status(201).json({ usuario: novoUsuario, token });
  } catch (err) {
    res.status(500).json({ erro: "Erro no registro" });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, senha } = req.body;
    const usuario = await User.findOne({ email });
    if (!usuario) return res.status(404).json({ erro: "Usuário não encontrado" });

    const senhaOk = await usuario.compararSenha(senha);
    if (!senhaOk) return res.status(401).json({ erro: "Senha incorreta" });

    const token = gerarToken(usuario);
    res.json({ usuario, token });
  } catch (err) {
    res.status(500).json({ erro: "Erro no login" });
  }
};
