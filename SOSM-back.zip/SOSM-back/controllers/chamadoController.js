const Chamado = require("../models/Chamado");

exports.criarChamado = async (req, res) => {
  try {
    const { titulo, descricao, prioridade } = req.body;
    const novo = await Chamado.create({
      titulo,
      descricao,
      prioridade,
      criadoPor: req.usuario.id,
    });
    res.status(201).json(novo);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao criar chamado" });
  }
};

exports.listarMeusChamados = async (req, res) => {
  try {
    const chamados = await Chamado.find({ criadoPor: req.usuario.id }).populate("atribuidoPara", "nome");
    res.json(chamados);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao buscar chamados" });
  }
};

exports.listarTodosChamados = async (req, res) => {
  try {
    const chamados = await Chamado.find()
      .populate("criadoPor", "nome")
      .populate("atribuidoPara", "nome");
    res.json(chamados);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao listar chamados" });
  }
};

exports.atualizarStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const chamado = await Chamado.findByIdAndUpdate(id, { status }, { new: true });
    res.json(chamado);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao atualizar status" });
  }
};

exports.atribuirChamado = async (req, res) => {
  try {
    const { id } = req.params;
    const { atendenteId } = req.body;
    const chamado = await Chamado.findByIdAndUpdate(id, { atribuidoPara: atendenteId }, { new: true });
    res.json(chamado);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao atribuir chamado" });
  }
};

exports.adicionarMensagem = async (req, res) => {
  try {
    const { id } = req.params;
    const { mensagem } = req.body;

    const chamado = await Chamado.findById(id);
    if (!chamado) return res.status(404).json({ erro: "Chamado não encontrado" });

    chamado.historico.push({
      mensagem,
      autor: req.usuario.id
    });

    await chamado.save();

    res.json({ mensagem: "Mensagem adicionada com sucesso", historico: chamado.historico });
  } catch (err) {
    res.status(500).json({ erro: "Erro ao adicionar mensagem ao chamado" });
  }
};

exports.detalharChamado = async (req, res) => {
  try {
    const chamado = await Chamado.findById(req.params.id)
      .populate("criadoPor", "nome")
      .populate("atribuidoPara", "nome")
      .populate("historico.autor", "nome");

    if (!chamado) return res.status(404).json({ erro: "Chamado não encontrado" });
    res.json(chamado);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao buscar chamado" });
  }
};

exports.editarChamado = async (req, res) => {
  try {
    const { id } = req.params;
    const { titulo, descricao, prioridade } = req.body;
    const chamado = await Chamado.findById(id);

    if (!chamado) return res.status(404).json({ erro: "Chamado não encontrado" });

    if (chamado.status !== "Aberto") return res.status(400).json({ erro: "Chamado já está em atendimento ou finalizado" });
    if (String(chamado.criadoPor) !== req.usuario.id && req.usuario.papel !== "admin") {
      return res.status(403).json({ erro: "Sem permissão para editar este chamado" });
    }

    chamado.titulo = titulo || chamado.titulo;
    chamado.descricao = descricao || chamado.descricao;
    chamado.prioridade = prioridade || chamado.prioridade;

    await chamado.save();
    res.json(chamado);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao editar chamado" });
  }
};

exports.deletarChamado = async (req, res) => {
  try {
    const { id } = req.params;
    const chamado = await Chamado.findById(id);

    if (!chamado) return res.status(404).json({ erro: "Chamado não encontrado" });

    if (String(chamado.criadoPor) !== req.usuario.id && req.usuario.papel !== "admin") {
      return res.status(403).json({ erro: "Sem permissão para excluir este chamado" });
    }

    await chamado.deleteOne();
    res.json({ mensagem: "Chamado excluído com sucesso" });
  } catch (err) {
    res.status(500).json({ erro: "Erro ao excluir chamado" });
  }
};
